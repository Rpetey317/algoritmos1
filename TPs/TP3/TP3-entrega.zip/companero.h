#ifndef __PERSONAJE_H__
#define __PERSONAJE_H__

#include <stdio.h>
#include <stdbool.h>

// Personajes
#define OLAF 'O'
#define STITCH 'S'
#define JASMIN 'J'
#define MCQUEEN 'R'

//realiza todo el juego del tp1: las 4 preguntas, con los mensajes
//entre las preguntas y la intro/outro
//El resultado queda guardado en la variable personaje
void jugar_tp1(char* personaje);

#endif // __PERSONAJE_H__ 